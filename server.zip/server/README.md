#Funcionalidades

## Conexões

-Rota para listar o total de conexões realziadas;
-Rota para criar uma nova conexão;

## Aulas

-Rota para criar uma aula;
-Rota para listar aulas;
    -Filtrar por materia, dia da semana e horario;